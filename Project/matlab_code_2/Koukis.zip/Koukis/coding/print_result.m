function print_result(str)
% PRINT_RESULT is a (dummy) function for printing the important results in
% a unified way.

disp('--------------------------------------------------------');
disp(str)
disp('--------------------------------------------------------');
end